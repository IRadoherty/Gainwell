﻿using InRule.Authoring.BusinessLanguage;
using InRule.Authoring.BusinessLanguage.Tokens;
using InRule.Authoring.Reporting;
using InRule.Repository;
using InRule.Repository.RuleElements;
using InRule.Runtime;

namespace FrameworkTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var ruleAppRef = new FileSystemRuleApplicationReference(@"C:\Program Files (x86)\InRule\irServer\RuleEngineService\IisService\bin\RuleApps\BaseRules.ruleappx");
            var ruleAppDef = ruleAppRef.GetRuleApplicationDef();
            var engine = new TemplateEngine();
            engine.LoadStandardTemplateCatalog();
            engine.LoadRuleApplication(ruleAppDef);
            
            foreach (EntityDef entity in ruleAppDef.Entities)
            foreach (var ruleSet in entity.GetAllRuleSets())
            foreach (var rule in ruleSet.Rules)
                if (rule is LanguageRuleDef blDef)
                {
                    var blText = blDef.Attributes["blText"];
                    if (blText != null && blText != "")
                    {
                        var text = RuleAppReport.GetBusinessLanguageText(blDef, engine, TextOutputFormat.RawText);
                        var newText = text.Replace("\t", "  ");
                        string check = blText;
                        string stop = "";
                    }
                }
        }
    }
}
